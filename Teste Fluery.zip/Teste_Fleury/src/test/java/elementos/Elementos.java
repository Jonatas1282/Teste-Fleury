package elementos;

import org.openqa.selenium.By;
import pages.Browser;

	//Essa é a classe de elementos do teste

public class Elementos extends Browser {

	private By butonUnidades = By.xpath("//*[@href=\"/unidades\"]");
	private By selFacilidades = By.cssSelector("#checkoox-select-facilities");
	private By cookies = By.cssSelector("body > div.cc-window.cc-banner.cc-type-info.cc-theme-classic.cc-bottom.cc-color-override--817642188 > div.cc-compliance > a");
	private By butonAtendimentos = By.xpath("//*[@id=\"gatsby-focus-wrapper\"]/div[8]/div[3]/div[3]/div[1]/div[2]/div/div[8]");
	private By butonVacina = By.cssSelector("div.animationcomponentstyle__ForcedFade-sc-7lsrx1-1.ebkWHA > div > div:nth-child(11)");
	private By butonBicicletario = By.cssSelector("div.animationcomponentstyle__ForcedFade-sc-7lsrx1-1.ebkWHA > div > div:nth-child(5)");
	private By detalhes = By.xpath("//*[@id=\"button-see-on-map-2-republica-do-libano-i\"]/div");
	private By validarNomeUnidade = By.xpath("//*[@id=\"gatsby-focus-wrapper\"]/div[8]/div[2]/div/h1");
	
	public By getUnidades() {
		return butonUnidades;
	
	}   
	
	public By getSelFacilidades() {
		return selFacilidades;
	}
	
	public By getCookies() {
		return cookies;
	}
	

	public By getButonAtendimentos() {
		return butonAtendimentos;
	}

	public By getButonVacina() {
		return butonVacina;
	}

	public By getButonBicicletario() {
		return butonBicicletario;
	}

	public By getDetalhes() {
		return detalhes;
	}

	public By getValidarNomeUnidade() {
		return validarNomeUnidade;
	}

	
}
