package steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementos.Elementos;
import pages.Facilidades;
import pages.MenuUnidade;
import pages.Metodos;
import pages.Nome_Unidade;
import pages.Unidades;

public class Steps {

	//ponteiros chamando as classes pages objects, que irão ser executadas nos steps
	//criei uma classe para cada funcionalidade, para facilitar o entendimento
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	MenuUnidade menu = new MenuUnidade();
	Facilidades facilidades = new Facilidades();
	Unidades unidades = new Unidades();
	Nome_Unidade validacao = new Nome_Unidade();

	@Given("^que eu esteja no site da Fleury$")
	public void que_eu_esteja_no_site_da_Fleury() throws Throwable {
		metodos.abrirNavegador("http://www.fleury.com.br");

	}

	@When("^acesso as unidades$")
	public void acesso_as_unidades() throws Exception {
		menu.Pesquisar();

	}

	@When("^seleciono a opcao de facilidade$")
	public void seleciono_a_opcao_de_facilidade() throws Exception {
		facilidades.selFacilidades();

	}

	@When("^seleciono a primeira unidade que aparece$")
	public void seleciono_a_primeira_unidade_que_aparece() throws Exception {
		unidades.selUnidade();

	}

	@Then("^valido o nome da unidade selecionada$")
	public void valido_o_nome_da_unidade_selecionada() throws Exception {
		validacao.ValNomeUnidade("República do Líbano I");

	}

}
