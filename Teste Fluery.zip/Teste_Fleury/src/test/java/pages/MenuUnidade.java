package pages;

import elementos.Elementos;

public class MenuUnidade {
	
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	
	public void Pesquisar () throws Exception  {
		
		metodos.clicar(elemento.getUnidades());
		metodos.screenshot("CT01_Clicar_Unidades");
		
		
		
	}

}
