package pages;

import java.io.IOException;
import elementos.Elementos;

public class Nome_Unidade {
	
	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	
	public void ValNomeUnidade (String texto) throws IOException, Exception {
		
		metodos.esperar(3000);
		metodos.validarTexto(texto, elemento.getValidarNomeUnidade());
		metodos.screenshot("CT04_Validar_Nome_da_Unidade");
		
	}

}
