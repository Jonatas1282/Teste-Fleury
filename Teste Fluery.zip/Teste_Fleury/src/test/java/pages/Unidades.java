package pages;

import elementos.Elementos;

public class Unidades {

	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();
	
	public void selUnidade () throws Exception {
		
		metodos.clicar(elemento.getDetalhes());
		metodos.screenshot("CT03_Selecionar_Unidade");
				
	}
	
}
