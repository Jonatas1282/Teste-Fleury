package pages;

import elementos.Elementos;

public class Facilidades {

	Metodos metodos = new Metodos();
	Elementos elemento = new Elementos();

	
	public void selFacilidades() throws Exception {

		metodos.esperar(3000);
		metodos.clicar(elemento.getCookies());
		metodos.esperar(3000);
		metodos.clicar(elemento.getSelFacilidades());
		metodos.clicar(elemento.getButonBicicletario());
		metodos.clicar(elemento.getButonAtendimentos());
		metodos.clicar(elemento.getButonVacina());
		metodos.screenshot("CT02_Buscar_Unidades");
				
	}

}
