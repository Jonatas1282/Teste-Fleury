package executa;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import pages.Browser;

// utilizei o runwith para executar as ospcões do cucumber
@RunWith(Cucumber.class)

//aqui estão o caminho onde será executado o runner
@CucumberOptions (
		
		//caminho da feature
		features = "src/test/resources/Features",
		
		//indicação onde serão implementados os gurkins
		glue = "steps",
		
		//indicação do que deve ser executado
		tags = "@Executa",
		
		//verifica se está faltando implementar algum codigo 
		dryRun = false,
		
		//formata exibição dos caracteres especiais 
		monochrome = true,
		
		//plugim para gerar um report em html e json
		plugin = {"pretty", "html:target/report.html", "json:target/report.json"}
		
		)


public class Executa extends Browser {

	//metodo para fechar o browser
	@AfterClass
	public static void fecharPagina () {
		adriver().quit();
	}

	
}
